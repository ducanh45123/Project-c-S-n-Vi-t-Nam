/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin_controller;

import connection.connectionDB;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.Account;

/**
 *
 * @author Kha Chinh
 */
@WebServlet(name = "manageAccAdmin", urlPatterns = {"/manageacc"})
public class manageAccAdmin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    connectionDB conn;

    public void init() {
        conn = new connectionDB();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession ses = request.getSession();
            Account a = (Account) ses.getAttribute("account");
            if (a.getType() != 1) {
                return;
            }
            String option = request.getParameter("option");
            if (option.equals("2")) {
                String id = request.getParameter("id");
                conn.manageAccount_Admin(2, id, "", "", 0);
                response.sendRedirect("account");
            } else {
                String name = request.getParameter("name");
                String pass = request.getParameter("pass");
                String repass = request.getParameter("re-pass");
                int type = Integer.parseInt(request.getParameter("type"));
                if (option.equals("1")) {
                    Account checked_user = conn.checkUserExist(name);
                    if (pass.equals(repass) || checked_user != null) {
                        conn.manageAccount_Admin(1, "", name, pass, type);
                    }
                    response.sendRedirect("account");
                } else if (option.equals("3")) {
                    String id = request.getParameter("id");
                    conn.manageAccount_Admin(3, id, "", "", type);
                    response.sendRedirect("account");
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
