/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import models.Account;
import models.Cart;
import models.Category;
import models.History;
import models.Info;
import models.Origin;
import models.Packing;
import models.Product;
import models.Rate;
import models.Ship;
import models.Summary;
import models.Voucher;

/**
 *
 * @author Kha Chinh
 */
public class connectionDB {

    Connection con;

    public connectionDB() {
        try {
            con = new DBContext().getConnection();
            System.out.println("Ket noi thanh cong");
        } catch (Exception e) {
            System.out.println("Co loi ket noi " + e.getMessage());
        }
    }

    public Vector<Product> loadProduct() {
        Vector vec = new Vector();
        try {
            String sql = "select pr.*, o.[Name], pa.Measure, c.[Name]\n"
                    + "from Product pr, Origin o, Packing pa, Category c\n"
                    + "where pr.Origin_ID = o.ID AND pr.Packing_ID = pa.ID AND pr.Category_ID = c.ID\n"
                    + "order by pr.[Name] asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(String.valueOf(rs.getInt(1)));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(12));
                s.setCategory(rs.getString(14));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(13));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Vector<Origin> loadOrigin() {
        Vector vec = new Vector();
        try {
            String sql = "select * from Origin\n"
                    + "order by name asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Origin o = new Origin();
                o.setId(rs.getString(1));
                o.setName(rs.getString(2));
                vec.add(o);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Vector<Category> loadCategory() {
        Vector vec = new Vector();
        try {
            String sql = "select * from Category\n"
                    + "order by name asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Category c = new Category();
                c.setId(rs.getString(1));
                c.setName(rs.getString(2));
                vec.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Vector<Packing> loadPacking() {
        Vector vec = new Vector();
        try {
            String sql = "select * from Packing";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Packing p = new Packing();
                p.setId(rs.getString(1));
                p.setName(rs.getString(2));
                vec.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Vector<Product> searchByName(String searchInput) {
        Vector vec = new Vector();
        try {
            String sql = "select pr.*, o.[Name], pa.Measure, c.[Name]\n"
                    + "from Product pr, Origin o, Packing pa, Category c\n"
                    + "where pr.Origin_ID = o.ID AND pr.Category_ID = c.ID AND pr.Packing_ID = pa.ID AND pr.Name like ?\n"
                    + "order by pr.[Name] asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchInput + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(rs.getString(1));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(12));
                s.setCategory(rs.getString(14));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(13));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Product getProductById(String id) {
        try {
            String sql = "select pr.*, o.[Name], pa.Measure, c.[Name]\n"
                    + "from Product pr, Origin o, Packing pa, Category c\n"
                    + "where pr.Origin_ID = o.ID AND pr.Category_ID = c.ID AND pr.Packing_ID = pa.ID AND pr.ID = ?\n"
                    + "order by pr.[Name] asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(rs.getString(1));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(12));
                s.setCategory(rs.getString(14));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(13));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                s.setOid(rs.getInt(4));
                s.setCid(rs.getInt(5));
                return s;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
            System.out.println(id);
        }
        return null;
    }

    public Account getAccountById(String id) {
        try {
            String sql = "select ID, [User_Name], [Type]\n"
                    + "from Account\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setId(rs.getString(1));
                a.setUsername(rs.getString(2));
                a.setType(rs.getInt(3));
                return a;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public Vector<Product> getProductFilter(int option, String input) {
        Vector vec = new Vector();
        try {
            String sql = "select pr.*, o.[Name], pa.Measure, c.[Name]\n"
                    + "from Product pr, Origin o, Packing pa, Category c\n"
                    + "where pr.Origin_ID = o.ID AND pr.Category_ID = c.ID AND pr.Packing_ID = pa.ID AND ";
            if (option == 1) {
                sql = sql + "o.ID = ?";
            } else if (option == 2) {
                sql = sql + "c.ID = ?";
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, input);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(rs.getString(1));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(12));
                s.setCategory(rs.getString(5));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(13));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Account Login(String username, String password) {
        try {
            String sql = "select * from account\n"
                    + "where [User_Name] = ? AND [Password] = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setId(rs.getString(1));
                a.setUsername(rs.getString(2));
                a.setPassword(rs.getString(3));
                a.setType(rs.getInt(4));
                return a;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public void Signup(String username, String password) {
        try {
            String sql = "insert into Account\n"
                    + "values (?, ?, '4')";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void manageAccount(String aid, String update, int option) {
        PreparedStatement ps;
        String sql = null;
        try {
            switch (option) {
                case 1:
                    sql = "update Account\n"
                            + "set User_Name = ?\n"
                            + "where ID = ?";
                    break;
                case 2:
                    sql = "update Account\n"
                            + "set Password = ?\n"
                            + "where ID = ?";
                    break;
            }
            ps = con.prepareStatement(sql);
            ps.setString(1, update);
            ps.setString(2, aid);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Account checkUserExist(String username) {
        try {
            String sql = "select * from Account\n"
                    + "where User_Name = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setId(rs.getString(1));
                a.setUsername(rs.getString(2));
                a.setPassword(rs.getString(3));
                a.setType(rs.getInt(4));
                return a;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public Info getInfoByAccountId(String acc_id) {
        try {
            String sql = "select * from Info\n"
                    + "where Account_ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, acc_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Info i = new Info();
                i.setAcc_id(rs.getString(1));
                i.setName(rs.getString(2));
                i.setGender(rs.getBoolean(3) ? "Nam" : "Nữ");
                i.setBirth(rs.getString(4));
                i.setPhone(rs.getString(5));
                i.setEmail(rs.getString(6));
                i.setAddress(rs.getString(7));
                return i;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public void manageInfo(String acc_id, String name, boolean gender,
            String birth, String phone, String email, String address, int option) {
        PreparedStatement ps;
        String sql;
        try {
            switch (option) {
                case 1:
                    sql = "insert into Info\n"
                            + "values (?, ?, ?, ?, ?, ?, ?)";
                    ps = con.prepareStatement(sql);
                    ps.setString(2, name);
                    ps.setBoolean(3, gender);
                    ps.setString(4, birth);
                    ps.setString(5, phone);
                    ps.setString(6, email);
                    ps.setString(7, address);
                    ps.setString(1, acc_id);
                    ps.executeUpdate();
                    break;
                case 2:
                    sql = "update Info\n"
                            + "set [Name] = ?, Gender = ?\n"
                            + ", Birth = ?, Phone_Number = ?\n"
                            + ", Email = ?, [Address] = ?\n"
                            + "where Account_ID = ?";
                    ps = con.prepareStatement(sql);
                    ps.setString(1, name);
                    ps.setBoolean(2, gender);
                    ps.setString(3, birth);
                    ps.setString(4, phone);
                    ps.setString(5, email);
                    ps.setString(6, address);
                    ps.setString(7, acc_id);
                    ps.executeUpdate();
                    break;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public static boolean validateDate(String strDate) {
        SimpleDateFormat sdfrmt = new SimpleDateFormat("dd/MM/yyyy");
        sdfrmt.setLenient(false);
        try {
            Date def = sdfrmt.parse(strDate);
            DateFormat format = new SimpleDateFormat("EEEE");
            String dayOfWeek = format.format(def);
        } catch (ParseException e) {
            System.out.println(strDate + " is not exits");
            return false;
        }
        return true;
    }

    public boolean checkCartExist(String aid, String pid) {
        String a = "";
        String p = "";
        try {
            String sql = "select * from Cart\n"
                    + "where Account_ID = ? AND Product_ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, aid);
            ps.setString(2, pid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a = rs.getString(1);
                p = rs.getString(2);
            }
            if (a.equals("") || p.equals("")) {
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return true;
    }

    public void manageProductAmount(boolean option, String pid) {
        try {
            String sql;
            if (option) {
                sql = "update Product\n"
                        + "set Amount = Amount - 1\n"
                        + "where ID = ?";
            } else {
                sql = "update Product\n"
                        + "set Amount = Amount + 1\n"
                        + "where ID = ?";
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pid);;
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void manageCart(String aid, String pid, boolean option1, boolean option2) {
        try {
            String sql;
            if (option1) { // add or delete product from Cart
                if (option2) { // add
                    manageProductAmount(true, pid);
                    sql = "insert into Cart\n"
                            + "values (?, ?, 1)";
                } else { // delete
                    manageProductAmount(false, pid);
                    sql = "delete from Cart\n"
                            + "where Account_ID = ? AND Product_ID = ?";
                }
            } else { // change amount of product in Cart
                if (option2) { // amount + 1
                    manageProductAmount(option2, pid);
                    sql = "update Cart\n"
                            + "set Amount = Amount + 1\n"
                            + "where Account_ID = ? AND Product_ID = ?";
                } else { // amount - 1
                    manageProductAmount(option2, pid);
                    sql = "update Cart\n"
                            + "set Amount = Amount - 1\n"
                            + "where Account_ID = ? AND Product_ID = ?";
                }
            }
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, aid);
            ps.setString(2, pid);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Cart> getCart(String Acc_id) {
        Vector vec = new Vector();
        try {
            String sql = "select a.ID, pr.ID, pr.Name, pr.Image, pr.Price, pa.Measure, pr.Amount, c.Amount\n"
                    + "from Account a, Product pr, Cart c, Packing pa\n"
                    + "where a.ID = c.Account_ID AND pr.ID = c.Product_ID\n"
                    + "AND pr.Packing_ID = pa.ID AND a.ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, Acc_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cart c = new Cart();
                c.setAccount_ID(rs.getString(1));
                c.setPid(rs.getString(2));
                c.setName(rs.getString(3));
                c.setImage(rs.getString(4));
                c.setPrice(rs.getInt(5));
                c.setPacking(rs.getString(6));
                c.setAmount(rs.getString(7));
                c.setQuantity(rs.getInt(8));
                vec.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Voucher getVoucher(String code) {
        try {
            String sql = "select * from Voucher\n"
                    + "where Code = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Voucher v = new Voucher();
                v.setCode(rs.getString(1));
                v.setName(rs.getString(2));
                v.setDiscount(rs.getFloat(3));
                v.setIsuse(rs.getBoolean(4));
                return v;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public boolean checkInfoExist(String aid) {
        try {
            String sql = "select [Name], Phone_Number, [Address]\n"
                    + "from Info\n"
                    + "where Account_ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, aid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getString(1) == null || rs.getString(2) == null
                        || rs.getString(3) == null) {
                    return false;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return true;
    }

    public void addShip(String aid, String voucher) {
        try {
            String add = "insert into Shipping (Status_ID ,Customer_ID, Product_ID, Amount, Price, Voucher_ID)\n"
                    + "select 1, c.Account_ID, c.Product_ID, c.Amount, p.Price, ?\n"
                    + "from Cart c, Product p\n"
                    + "where c.Product_ID = p.ID and c.Account_ID = ?";
            String delete = "delete from Cart\n"
                    + "where Account_ID = ?";
            PreparedStatement ps = con.prepareStatement(add);
            if (voucher.equals("")) {
                ps.setString(1, null);
            } else {
                ps.setString(1, voucher);
            }
            ps.setString(2, aid);
            ps.executeUpdate();
            PreparedStatement del = con.prepareStatement(delete);
            del.setString(1, aid);
            del.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Ship> getShip(String acc_id, boolean option, int status) {
        Vector vec = new Vector();
        try {
            if (option) {
                String sql = "select sh.ID, pr.[Name], pr.[Image], sh.Amount, sh.Shipper_ID, st.[Name], sh.Price, st.ID, pr.ID\n"
                        + "from Shipping sh, [Status] st, Product pr, Info i\n"
                        + "where sh.Status_ID = st.ID and sh.Product_ID = pr.ID\n"
                        + "and sh.Customer_ID = i.Account_ID and Account_ID = ?\n"
                        + "order by st.ID desc";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, acc_id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Ship s = new Ship();
                    s.setId(rs.getString(1));
                    s.setProduct(rs.getString(2));
                    s.setImage(rs.getString(3));
                    s.setAmount(rs.getInt(4));
                    if (rs.getString(5) == null) {
                        s.setShipper("none");
                    } else {
                        Info i = getInfoByAccountId(rs.getString(5));
                        s.setShipper(i.getName());
                    }
                    s.setStatus(rs.getString(6));
                    s.setPrice(rs.getInt(7));
                    s.setSid(rs.getInt(8));
                    s.setPid(rs.getInt(9));
                    vec.add(s);
                }
            } else {
                String sql = "select sh.ID, pr.[Name], pr.[Image], sh.Amount, i.[Name],\n"
                        + "i.[Address], i.Phone_Number, sh.Status_ID\n"
                        + "from Shipping sh, Product pr, Info i\n"
                        + "where sh.Product_ID = pr.ID and sh.Customer_ID = i.Account_ID\n"
                        + "and Shipper_ID";
                if (status == 1) {
                    sql = sql + " is null";
                } else {
                    sql = sql + " = ?";
                }
                PreparedStatement ps = con.prepareStatement(sql);
                if (status != 1) {
                    ps.setString(1, acc_id);
                }
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Ship s = new Ship();
                    s.setId(rs.getString(1));
                    s.setProduct(rs.getString(2));
                    s.setImage(rs.getString(3));
                    s.setAmount(rs.getInt(4));
                    s.setCustomer(rs.getString(5));
                    s.setAddress(rs.getString(6));
                    s.setPhone(rs.getString(7));
                    s.setSid(rs.getInt(8));
                    vec.add(s);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void manageShip(String order_id, String shipper_id, int step) {
        try {
            if (step > 1) {
                String add = "update Shipping\n"
                        + "set Shipper_ID = ?\n"
                        + "where ID = ?";
                PreparedStatement ps = con.prepareStatement(add);
                ps.setString(1, shipper_id);
                ps.setString(2, order_id);
                ps.executeUpdate();
            }
            if (step > 0) {
                String status = "update Shipping\n"
                        + "set Status_ID = Status_ID + 1\n"
                        + "where ID = ?";
                PreparedStatement st = con.prepareStatement(status);
                st.setString(1, order_id);
                st.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void cancelOrder(String oid, String pid, String amount) {
        try {
            String back = "update Product\n"
                    + "set Amount = Amount + ?\n"
                    + "where ID = ?";
            PreparedStatement pr1 = con.prepareStatement(back);
            pr1.setString(1, amount);
            pr1.setString(2, pid);
            pr1.executeUpdate();
            String delete = "delete from Shipping\n"
                    + "where ID = ?";
            PreparedStatement pr2 = con.prepareStatement(delete);
            pr2.setString(1, oid);
            pr2.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void addHistory(String id, String date) {
        try {
            String add = "insert into History(ID ,Customer_ID, Product_ID, Shipper_ID, Amount, Price, [Date], Voucher_ID)\n"
                    + "select s.ID, s.Customer_ID, s.Product_ID, s.Shipper_ID, s.Amount, s.Price, ?, s.Voucher_ID\n"
                    + "from Shipping s\n"
                    + "where s.ID = ?";
            String delete = "delete from Shipping\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(add);
            ps.setString(1, date);
            ps.setString(2, id);
            ps.executeUpdate();
            PreparedStatement del = con.prepareStatement(delete);
            del.setString(1, id);
            del.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<History> getHistory(String acc_id, boolean option) {
        Vector vec = new Vector();
        try {
            if (option) {
                String sql = "select h.ID, p.[Name], p.[Image], h.Amount, h.Price, h.Shipper_ID, h.Voucher_ID, h.[Date], p.ID\n"
                        + "from History h, Product p\n"
                        + "where h.Product_ID = P.ID and h.Customer_ID = ?\n"
                        + "order by h.ID asc";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, acc_id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    History h = new History();
                    h.setId(rs.getString(1));
                    h.setName(rs.getString(2));
                    h.setImage(rs.getString(3));
                    h.setAmount(rs.getInt(4));
                    h.setPrice(rs.getInt(5));
                    h.setShipper(getInfoByAccountId(rs.getString(6)).getName());
                    Voucher v;
                    if (rs.getString(7) != null) {
                        v = getVoucher(rs.getString(7));
                        if (v.getName().equals("Ship 0 đồng")) {
                            h.setDiscount(0);
                        } else {
                            h.setDiscount(1 - v.getDiscount());
                        }

                    } else {
                        h.setDiscount(1);
                    }
                    h.setDate(rs.getString(8));
                    h.setPid(rs.getString(9));
                    vec.add(h);
                }
            } else {
                String sql = "select h.ID, p.[Name], h.Amount, i.[Name], i.[Address], i.Phone_Number, h.[Date]\n"
                        + "from History h, Product p, Info i\n"
                        + "where h.Customer_ID = i.Account_ID and h.Product_ID = p.ID and h.Shipper_ID = ?\n"
                        + "order by h.ID asc";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, acc_id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    History h = new History();
                    h.setId(rs.getString(1));
                    h.setName(rs.getString(2));
                    h.setAmount(rs.getInt(3));
                    h.setCustomer(rs.getString(4));
                    h.setAddress(rs.getString(5));
                    h.setPhone(rs.getString(6));
                    h.setDate(rs.getString(7));
                    vec.add(h);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Vector<Product> getProductBySellID(String aid) {
        Vector vec = new Vector();
        try {
            String sql = "select pr.*, o.[Name], pa.Measure, c.[Name]\n"
                    + "from Product pr, Origin o, Packing pa, Category c\n"
                    + "where pr.Origin_ID = o.ID AND pr.Category_ID = c.ID AND pr.Packing_ID = pa.ID AND Sell_ID = ?\n"
                    + "order by pr.[Name] asc";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, aid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(rs.getString(1));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(12));
                s.setCategory(rs.getString(5));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(13));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void deleteProduct(String pid) {
        try {
            String sql = "delete from Product\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pid);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void manageStore(String option, String id, String name, String image,
            String origin, String category, String price, String packing,
            String sid, String amount, String description) {
        try {
            String add = "insert into Product ([Name], [Image], Origin_ID, Category_ID,\n"
                    + "Price, Packing_ID, Sell_ID, Amount, [Description], isActive)\n"
                    + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
            String edit = "update Product\n"
                    + "set [Name] = ?, [Image] = ?, Origin_ID = ?, Category_ID = ?,\n"
                    + "Price = ?, Packing_ID = ?, Amount = ?, [Description] = ?\n"
                    + "where ID = ?";
            if (option.equals("2")) {
                PreparedStatement ps = con.prepareStatement(add);
                ps.setString(1, name);
                ps.setString(2, image);
                ps.setString(3, origin);
                ps.setString(4, category);
                ps.setString(5, price);
                ps.setString(6, packing);
                ps.setString(7, sid);
                ps.setString(8, amount);
                ps.setString(9, description);
                ps.executeUpdate();
            } else if (option.equals("3")) {
                PreparedStatement ps = con.prepareStatement(edit);
                ps.setString(1, name);
                ps.setString(2, image);
                ps.setString(3, origin);
                ps.setString(4, category);
                ps.setString(5, price);
                ps.setString(6, packing);
                ps.setString(7, amount);
                ps.setString(8, description);
                ps.setString(9, id);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Product> loadProduct_Admin() {
        Vector vec = new Vector();
        try {
            String sql = "select pr.ID, pr.[Name], pr.[Image], o.[Name], c.[Name], pr.Price,\n"
                    + "pa.Measure, pr.[Amount], a.[User_Name], pr.[Description], pr.isActive\n"
                    + "from Product pr, Origin o, Category c, Packing pa, Account a\n"
                    + "where pr.Origin_ID = o.ID and pr.Category_ID = c.ID \n"
                    + "and pr.Packing_ID = pa.ID and pr.Sell_ID = a.ID";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product s = new Product();
                s.setId(String.valueOf(rs.getInt(1)));
                s.setName(rs.getString(2));
                s.setImage(rs.getString(3));
                s.setOrigin(rs.getString(4));
                s.setCategory(rs.getString(5));
                s.setPrice(rs.getInt(6));
                s.setPacking(rs.getString(7));
                s.setAmount(rs.getInt(8));
                s.setSid(rs.getString(9));
                s.setDescription(rs.getString(10));
                s.setActive(rs.getBoolean(11));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void manageProductActive(String id, int active) {
        try {
            String sql = "update Product\n"
                    + "set isActive = ?\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, active);
            ps.setString(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Account> loadAccount_Admin() {
        Vector vec = new Vector();
        try {
            String sql = "select ID, [User_Name], [Type]\n"
                    + "from Account";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setId(rs.getString(1));
                a.setUsername(rs.getString(2));
                a.setType(rs.getInt(3));
                vec.add(a);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void manageAccount_Admin(int option, String id, String name, String pass, int type) {
        try {
            String add = "insert into Account\n"
                    + "values (?, ?, ?)";
            String delete = "delete from Account\n"
                    + "where ID = ?";
            String edit = "update Account\n"
                    + "set [Type] = ?\n"
                    + "where ID = ?";
            PreparedStatement ps;
            switch (option) {
                case 1:
                    ps = con.prepareStatement(add);
                    ps.setString(1, name);
                    ps.setString(2, pass);
                    ps.setInt(3, type);
                    break;
                case 2:
                    ps = con.prepareStatement(delete);
                    ps.setString(1, id);
                    break;
                default:
                    ps = con.prepareStatement(edit);
                    ps.setInt(1, type);
                    ps.setString(2, id);
                    break;
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Voucher> loadVoucher() {
        Vector vec = new Vector();
        try {
            String sql = "select * from Voucher";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Voucher v = new Voucher();
                v.setCode(rs.getString(1));
                v.setName(rs.getString(2));
                v.setDiscount(rs.getFloat(3));
                v.setIsuse(rs.getBoolean(4));
                vec.add(v);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void manageVoucher(int option, String code, String name,
            float discount, boolean use) {
        try {
            String add = "insert into Voucher\n"
                    + "values (?, ?, ?, ?)";
            String delete = "delete from voucher\n"
                    + "where Code = ?";
            String edit = "update Voucher\n"
                    + "set Name = ?, Discount = ?, isUse = ?\n"
                    + "where Code = ?";
            PreparedStatement ps;
            switch (option) {
                case 1:
                    ps = con.prepareStatement(add);
                    ps.setString(1, code);
                    ps.setString(2, name);
                    ps.setFloat(3, discount);
                    ps.setBoolean(4, use);
                    break;
                case 2:
                    ps = con.prepareStatement(delete);
                    ps.setString(1, code);
                    break;
                default:
                    ps = con.prepareStatement(edit);
                    ps.setString(1, name);
                    ps.setFloat(2, discount);
                    ps.setBoolean(3, use);
                    ps.setString(4, code);
                    break;
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public int Top(int option, String start, String end) {
        try {
            String date = "where [Date] between '" + start + "' and '" + end + "'";
            String receipt = "select count(id)\n"
                    + "from History\n"
                    + date;
            String amount = "select SUM(amount)\n"
                    + "from History\n"
                    + date;
            PreparedStatement ps;
            if (option == 1) {
                ps = con.prepareStatement(receipt);
            } else {
                ps = con.prepareStatement(amount);
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return 0;
    }

    public Vector<Summary> Summary(int option, String start, String end) {
        Vector vec = new Vector();
        try {
            String date = "where [Date] between '" + start + "' and '" + end + "'";
            String shipper = "select i.[Name], a.[User_Name], COUNT(*) as num\n"
                    + "from History h, Info i, Account a\n"
                    + date + "\n"
                    + "and h.Shipper_ID = i.Account_ID and h.Shipper_ID = a.ID\n"
                    + "group by i.[Name], a.[User_Name]\n"
                    + "order by num desc";
            String customer = "select i.[Name], a.[User_Name], COUNT(*) as num\n"
                    + "from History h, Info i, Account a\n"
                    + date + "\n"
                    + "and h.Customer_ID = i.Account_ID and h.Customer_ID = a.ID\n"
                    + "group by i.[Name], a.[User_Name]\n"
                    + "order by num desc";
            String product = "select p.[Name], a.[User_Name], SUM(h.Amount) as num\n"
                    + "from History h, Product p, Account a\n"
                    + date + "\n"
                    + "and h.Product_ID = p.ID and p.Sell_ID = a.ID\n"
                    + "group by p.[Name], a.[User_Name]\n"
                    + "order by num desc";
            PreparedStatement ps;
            switch (option) {
                case 1:
                    ps = con.prepareStatement(shipper);
                    break;
                case 2:
                    ps = con.prepareStatement(customer);
                    break;
                default:
                    ps = con.prepareStatement(product);
                    break;
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Summary s = new Summary();
                s.setName(rs.getString(1));
                s.setAmount(rs.getInt(3));
                s.setUser(rs.getString(2));
                vec.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public void manageRate(int option, String id, float rate, String comment, String cid, String pid) {
        try {
            String add = "insert into Rate\n"
                    + "values (?, ?, ?, ?, ?)";
            String delete = "delete from Rate\n"
                    + "where ID = ?";
            String edit = "update Rate\n"
                    + "set Rate = ?, Comment = ?\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(add);
            switch (option) {
                case 1:
                    ps.setString(1, id);
                    ps.setFloat(2, rate);
                    ps.setString(3, comment);
                    ps.setString(4, cid);
                    ps.setString(5, pid);
                    break;
                case 2:
                    ps = con.prepareStatement(delete);
                    ps.setString(1, id);
                    break;
                case 3:
                    ps = con.prepareStatement(edit);
                    ps.setString(3, id);
                    ps.setFloat(1, rate);
                    ps.setString(2, comment);
                    break;
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public Vector<Rate> loadRate(String pid) {
        Vector vec = new Vector();
        try {
            String sql = "select *\n"
                    + "from Rate\n"
                    + "where Product_ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rate r = new Rate();
                r.setId(rs.getString(1));
                r.setRate(rs.getFloat(2));
                r.setComment(rs.getString(3));
                r.setCustomer(getAccountById(rs.getString(4)).getUsername());
                r.setPid(rs.getString(5));
                vec.add(r);
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return vec;
    }

    public Rate getRateById(String id) {
        try {
            String sql = "select *\n"
                    + "from Rate\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rate r = new Rate();
                r.setId(rs.getString(1));
                r.setRate(rs.getFloat(2));
                r.setComment(rs.getString(3));
                r.setCustomer(getAccountById(rs.getString(4)).getUsername());
                r.setPid(rs.getString(5));
                return r;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return null;
    }

    public boolean checkRateExist(String id) {
        try {
            String sql = "select ID from Rate\n"
                    + "where ID = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            String check = "";
            while (rs.next()) {
                check = rs.getString(1);
            }
            if (check.equals("")) {
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return true;
    }

    public static void main(String[] args) {
        connectionDB conn = new connectionDB();
        Vector<History> h = conn.getHistory("13", true);
        for (History s : h) {
            System.out.println(s.getDiscount());
        }

//        System.out.println(conn.Top(2, "2021-10-01", "2021-10-31"));
    }
}
