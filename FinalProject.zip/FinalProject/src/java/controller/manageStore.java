/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import connection.connectionDB;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.Account;

/**
 *
 * @author Kha Chinh
 */
@WebServlet(name = "manageStore", urlPatterns = {"/managestore"})
public class manageStore extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    connectionDB conn;

    public void init() {
        conn = new connectionDB();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            request.setCharacterEncoding("UTF-8");
            HttpSession ses = request.getSession();
            Account a = (Account) ses.getAttribute("account");
            if (a.getType() > 2) {
                return;
            }
            String option = request.getParameter("option");
            if (option.equals("1")) {
                String id = request.getParameter("id");
                conn.deleteProduct(id);
                if (a.getType() == 2) {
                    response.sendRedirect("store");
                } else {
                    response.sendRedirect("product");
                }
            } else if (option.equals("4")) {
                String id = request.getParameter("id");
                int active = Integer.parseInt(request.getParameter("active"));
                if (active == 0) {
                    conn.manageProductActive(id, 0);
                } else {
                    conn.manageProductActive(id, 1);
                }
                response.sendRedirect("product");

            } else if (a.getType() == 2) {
                String name = request.getParameter("name");
                String image = request.getParameter("image");
                String origin = request.getParameter("origin");
                String category = request.getParameter("category");
                String price = request.getParameter("price");
                String packing = request.getParameter("packing");
                String amount = request.getParameter("amount");
                String description = request.getParameter("description");
                if (option.equals("2")) {
                    conn.manageStore(option, "", name, image, origin, category, price, packing, a.getId(), amount, description);
                    response.sendRedirect("store");
                } else if (option.equals("3")) {
                    String id = request.getParameter("id");
                    conn.manageStore(option, id, name, image, origin, category, price, packing, "", amount, description);
                    response.sendRedirect("store");
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
