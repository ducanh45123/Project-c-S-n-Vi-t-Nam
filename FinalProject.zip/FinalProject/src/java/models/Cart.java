/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Kha Chinh
 */
public class Cart {
    private String Account_ID;
    private String pid;
    private String name;
    private String image;
    private int price;
    private String packing;
    private String amount;
    private int quantity;

    public Cart() {
    }

    public Cart(String Account_ID, String pid, String name, String image, int price, String packing, String amount, int quantity) {
        this.Account_ID = Account_ID;
        this.pid = pid;
        this.name = name;
        this.image = image;
        this.price = price;
        this.packing = packing;
        this.amount = amount;
        this.quantity = quantity;
    }

    public String getAccount_ID() {
        return Account_ID;
    }

    public void setAccount_ID(String Account_ID) {
        this.Account_ID = Account_ID;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPacking() {
        return packing;
    }

    public void setPacking(String packing) {
        this.packing = packing;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


}
